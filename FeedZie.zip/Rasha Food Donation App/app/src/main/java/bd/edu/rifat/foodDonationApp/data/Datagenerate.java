package bd.edu.rifat.foodDonationApp.data;

import java.util.ArrayList;
import java.util.List;

public class Datagenerate {


    public static List<String> foodGroup = new ArrayList<>();

    static {
        foodGroup.add("✔");
        foodGroup.add("✔");
        foodGroup.add("✔");
        foodGroup.add("✔");
        foodGroup.add("✔");
        foodGroup.add("✔");
        foodGroup.add("✔");
        foodGroup.add("✔");

    }
}
